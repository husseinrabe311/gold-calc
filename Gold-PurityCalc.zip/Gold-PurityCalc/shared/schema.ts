import { pgTable, text, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const contactSubmissions = pgTable("contact_submissions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  message: text("message").notNull(),
});

export const insertContactSchema = createInsertSchema(contactSubmissions).omit({ id: true });

export type ContactSubmission = typeof contactSubmissions.$inferSelect;
export type InsertContactSubmission = z.infer<typeof insertContactSchema>;

// Calculator types (frontend state management)
export const purityEnum = z.enum(["24k", "22k", "18k"]);
export type Purity = z.infer<typeof purityEnum>;

export const calculatorSchema = z.object({
  pricePerOunce: z.coerce.number().min(0, "Price must be positive"),
  weightInGrams: z.coerce.number().min(0, "Weight must be positive"),
  purity: purityEnum,
});

export type CalculatorInput = z.infer<typeof calculatorSchema>;
