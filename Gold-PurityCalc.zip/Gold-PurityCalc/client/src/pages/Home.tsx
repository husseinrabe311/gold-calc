import { useState } from "react";
import { Calculator, HelpCircle, TrendingUp, Info } from "lucide-react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

// Purity factors based on implementation notes
const PURITY_FACTORS = {
  "24k": 1.0,
  "22k": 0.9167,
  "18k": 0.75,
};

type PurityType = keyof typeof PURITY_FACTORS;

export default function Home() {
  const [pricePerOunce, setPricePerOunce] = useState<string>("");
  const [weight, setWeight] = useState<string>("");
  const [purity, setPurity] = useState<PurityType>("24k");

  const calculateValue = () => {
    const price = parseFloat(pricePerOunce);
    const weightGrams = parseFloat(weight);
    
    if (isNaN(price) || isNaN(weightGrams)) return 0;
    
    // Formula: (Price / 31.1035) * Weight * PurityFactor
    const pricePerGram = price / 31.1035;
    const rawValue = pricePerGram * weightGrams * PURITY_FACTORS[purity];
    
    return rawValue;
  };

  const totalValue = calculateValue();
  const hasInput = pricePerOunce && weight;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-12 lg:py-24 overflow-hidden">
          <div className="absolute inset-0 z-0 opacity-30">
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-primary/20 rounded-full blur-3xl"></div>
            <div className="absolute top-1/2 -left-24 w-64 h-64 bg-yellow-200/20 rounded-full blur-3xl"></div>
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12 max-w-2xl mx-auto">
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-4"
              >
                Gold Value <span className="text-gradient">Calculator</span>
              </motion.h1>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="text-lg text-muted-foreground"
              >
                Instantly estimate the scrap value of your gold jewelry, coins, and bullion.
              </motion.p>
            </div>

            <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-start max-w-5xl mx-auto">
              {/* Calculator Card */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <Card className="shadow-xl border-primary/10 overflow-hidden bg-white/50 backdrop-blur-sm">
                  <div className="h-2 bg-gradient-to-r from-yellow-500 to-yellow-300 w-full" />
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-2xl">
                      <Calculator className="w-6 h-6 text-primary" />
                      Calculate Value
                    </CardTitle>
                    <CardDescription>
                      Enter current market price and item weight
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <label htmlFor="price" className="text-sm font-medium text-foreground">
                        Gold Spot Price (USD/oz)
                      </label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                        <input
                          id="price"
                          type="number"
                          placeholder="2500.00"
                          value={pricePerOunce}
                          onChange={(e) => setPricePerOunce(e.target.value)}
                          className="w-full pl-8 pr-4 py-3 rounded-lg bg-background border border-input focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all outline-none"
                        />
                      </div>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" /> 
                        Check current market rates online for accuracy
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label htmlFor="weight" className="text-sm font-medium text-foreground">
                          Weight (grams)
                        </label>
                        <input
                          id="weight"
                          type="number"
                          placeholder="Enter value to calculate"
                          value={weight}
                          onChange={(e) => setWeight(e.target.value)}
                          className="w-full px-4 py-3 rounded-lg bg-background border border-input focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all outline-none"
                        />
                      </div>

                      <div className="space-y-2">
                        <label htmlFor="purity" className="text-sm font-medium text-foreground">
                          Purity (Karat)
                        </label>
                        <select
                          id="purity"
                          value={purity}
                          onChange={(e) => setPurity(e.target.value as PurityType)}
                          className="w-full px-4 py-3 rounded-lg bg-background border border-input focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all outline-none appearance-none"
                        >
                          <option value="24k">24k (99.9%)</option>
                          <option value="22k">22k (91.6%)</option>
                          <option value="18k">18k (75.0%)</option>
                        </select>
                      </div>
                    </div>

                    <div className={`mt-8 p-6 rounded-xl transition-all duration-300 ${hasInput ? 'bg-primary/10 border border-primary/20' : 'bg-muted/30 border border-border'}`}>
                      <div className="text-center">
                        <p className="text-sm font-medium text-muted-foreground mb-1 uppercase tracking-wide">Estimated Value</p>
                        <p className={`font-display font-bold text-4xl ${hasInput ? 'text-primary' : 'text-muted-foreground'}`}>
                          {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(totalValue)}
                        </p>
                        <p className="mt-4 text-xs text-muted-foreground italic leading-relaxed">
                          Estimates are based on market spot prices and gold purity. Actual buy prices may vary by dealer.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* FAQ Section */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="space-y-6"
              >
                <div className="mb-4">
                  <h2 className="font-display text-2xl font-bold mb-2">Common Questions</h2>
                  <p className="text-muted-foreground">Understanding gold valuation basics.</p>
                </div>

                <div className="space-y-4">
                  <div className="bg-card rounded-lg p-5 border border-border/60 hover:border-primary/30 transition-colors shadow-sm">
                    <h3 className="font-semibold flex items-center gap-2 mb-2">
                      <HelpCircle className="w-4 h-4 text-primary" />
                      How is gold price calculated?
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Gold is typically traded in troy ounces. Our calculator takes the current spot price per ounce, converts it to grams (1 oz = 31.1035g), and then adjusts for the purity of your item.
                    </p>
                  </div>

                  <div className="bg-card rounded-lg p-5 border border-border/60 hover:border-primary/30 transition-colors shadow-sm">
                    <h3 className="font-semibold flex items-center gap-2 mb-2">
                      <Info className="w-4 h-4 text-primary" />
                      What is the difference in Karats?
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      <strong>24k</strong> is pure gold (99.9%). <strong>22k</strong> is 91.6% gold, often used in high-quality jewelry. <strong>18k</strong> is 75% gold, mixed with other metals for durability.
                    </p>
                  </div>

                  <div className="bg-card rounded-lg p-5 border border-border/60 hover:border-primary/30 transition-colors shadow-sm">
                    <h3 className="font-semibold flex items-center gap-2 mb-2">
                      <TrendingUp className="w-4 h-4 text-primary" />
                      How often does price change?
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Gold is a globally traded commodity. Its "spot price" changes constantly during trading hours (Monday-Friday) based on supply, demand, and economic factors.
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
