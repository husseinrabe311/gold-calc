import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { motion } from "framer-motion";
import { Shield, Target, Award } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1 py-12 lg:py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-16"
          >
            <h1 className="font-display text-4xl md:text-5xl font-bold mb-6">About GoldCalc</h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              We provide transparent, accurate tools for everyday people to understand the real value of their precious metals.
            </p>
          </motion.div>

          {/* Unsplash image: Jewelry/Gold workshop detail */}
          {/* <img src="https://images.unsplash.com/photo-1601121141461-9d660d5b1285?auto=format&fit=crop&q=80&w=2000" alt="Gold jewelry crafting" className="w-full h-64 md:h-96 object-cover rounded-2xl mb-16 shadow-lg" /> */}
          <div className="relative w-full h-64 md:h-80 rounded-2xl overflow-hidden mb-16 shadow-lg bg-secondary">
             {/* gold bars close up */}
            <img 
              src="https://images.unsplash.com/photo-1610375461246-83df859d849d?q=80&w=2070&auto=format&fit=crop" 
              alt="Gold bars and coins" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end p-8">
              <p className="text-white font-medium text-lg">Empowering you with knowledge.</p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="p-6 bg-card rounded-xl border border-border shadow-sm">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 text-primary">
                <Shield className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg mb-2">Transparency</h3>
              <p className="text-muted-foreground text-sm">
                No hidden formulas. We calculate value based purely on market weight and purity standards.
              </p>
            </div>

            <div className="p-6 bg-card rounded-xl border border-border shadow-sm">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 text-primary">
                <Target className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg mb-2">Accuracy</h3>
              <p className="text-muted-foreground text-sm">
                Our calculators use precise conversion rates (31.1035 grams per troy ounce) for exact estimates.
              </p>
            </div>

            <div className="p-6 bg-card rounded-xl border border-border shadow-sm">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 text-primary">
                <Award className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg mb-2">Education</h3>
              <p className="text-muted-foreground text-sm">
                We believe in educating users about the differences in karatage and market dynamics.
              </p>
            </div>
          </div>

          <div className="prose prose-gray max-w-none">
            <h2 className="font-display text-2xl font-bold mb-4">Our Mission</h2>
            <p className="text-muted-foreground leading-relaxed mb-6">
              Gold selling can be an opaque industry. Many cash-for-gold shops offer rates significantly below market value, relying on the customer's lack of knowledge. GoldCalc was built to change that. By providing an instant, mathematical baseline for what your items are worth as raw scrap metal, we empower you to negotiate better deals or know when to walk away.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Whether you have old 18k jewelry, 24k bullion coins, or broken 22k chains, knowing the melt value is the first step in maximizing your return.
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
