import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1 py-12 lg:py-24">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl font-bold mb-8">Privacy Policy</h1>
          
          <div className="prose prose-gray max-w-none space-y-8">
            <section>
              <h2 className="text-xl font-bold text-foreground mb-4">1. Information We Collect</h2>
              <p className="text-muted-foreground">
                When you use our calculator, we do not store the values you input. All calculations are performed instantly in your browser. 
                If you contact us via the contact form, we collect your name and email address solely to respond to your inquiry.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-foreground mb-4">2. How We Use Information</h2>
              <p className="text-muted-foreground">
                We use the information provided in contact forms to:
              </p>
              <ul className="list-disc pl-5 text-muted-foreground mt-2 space-y-2">
                <li>Respond to your questions and support requests.</li>
                <li>Improve our website based on your feedback.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-foreground mb-4">3. Data Security</h2>
              <p className="text-muted-foreground">
                We implement appropriate technical and organizational measures to protect your personal data against unauthorized access, alteration, disclosure, or destruction.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-foreground mb-4">4. Cookies</h2>
              <p className="text-muted-foreground">
                We may use essential cookies to ensure the website functions correctly. We do not use tracking cookies for advertising purposes.
              </p>
            </section>

            <section className="pt-8 border-t border-border">
              <p className="text-sm text-muted-foreground">
                Last updated: {new Date().toLocaleDateString()}
              </p>
            </section>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
